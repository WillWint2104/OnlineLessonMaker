# Annotated solutions — PR #157 review package

Source commit: **30502fdd3cd565a8d55e23a61595a829c0ae2622**. The application, assets and review files are exact Git objects from this commit. A later commit may add this ZIP itself without changing its source; compare PACKAGE-PROVENANCE.json and SHA256SUMS.txt, and the final PR receipt.

Extract the entire ZIP. Open **docs/review/annotated-solutions/index.html** for matched original-resolution captures and the recording. The before captures use the PR #156 renderer with the corrected review JSON, as labelled. They do not rewrite the historical audit.

Independent learner pages are **docs/review/annotated-solutions/after/published-factorising.html**, **published-physics.html**, **published-qualitative.html** and **published-authored-lesson.html**. Open them directly in a browser.

For the editable application, serve the extracted root: run **node scripts/serve-player.mjs**, then open http://127.0.0.1:8099/lesson-studio.html . This uses Node's standard library and needs no npm install. Alternatively use a static HTTP server rooted here. The application uses the included assets/ directory. Choose Edit → JSON and import **docs/review/annotated-solutions/after/authored-lesson-final.json** (or factorising.json / physics.json / qualitative.json). Select a worked example, step or table to edit. The exported learner HTML has no editing controls.

The recording is **after/authoring-walkthrough.webm**, screenshots are **before/**, **after/**, **zoom/** and **defects/**, and guides are README.md, REFERENCES.md, AUTHORING_COVERAGE.md and SCREENSHOT_INDEX.md inside the review directory. Verification records retain their actual source revisions in **verification/**; they are not relabelled as new runs. Included verification scripts are reference material, not a full test-runner installation.

Teacher video URLs/playback remain outstanding; the tablet question-reference enhancement remains deferred. External videos, remote media, optional 3D services and other remote dependencies are not promised offline or on a school network. The included synthetic lessons require no teacher-video playback. Merge is not teacher visual approval.

SHA256SUMS.txt covers every file except itself. PACKAGE-PROVENANCE.json identifies original source files. Packaging verification extracts the archive, checks all hashes against originals, local index links, required editable and learner files, and non-empty screenshots/recording.
